package src.tools;
import java.awt.*;
import javax.swing.*;
import java.util.*;

public class Components {
    HashMap<String,String> config;

    public Components(HashMap<String,String> c){
        config = c;
    }

    public void updateCfg(HashMap<String,String> cfg){
        config = cfg;
    }
    
    public int[] getPrimary(int... changeBy){
        int[] arr = new int[3];
        String[] strArr = config.get("primaryColour").split(",");
        for(int i = 0; i < arr.length; i++){
            int num = (changeBy.length == 0) ? 0 : (changeBy.length < 3) ? changeBy[0] : changeBy[i];
            arr[i] = Math.min(255, Math.max(0, Integer.parseInt(strArr[i])+num));
        }
        return arr;
    }
    public int[] getSecondary(int... changeBy){
        int[] arr = new int[3];
        String[] strArr = config.get("secondaryColour").split(",");
        for(int i = 0; i < arr.length; i++){
            int num = (changeBy.length == 0) ? 0 : (changeBy.length < 3) ? changeBy[0] : changeBy[i];
            arr[i] = Math.min(255, Math.max(0, Integer.parseInt(strArr[i])+num));
        }
        return arr;
    }
    public int[] getTertiary(int... changeBy){
        int[] arr = new int[3];
        String[] strArr = config.get("tertiaryColour").split(",");
        for(int i = 0; i < arr.length; i++){
            int num = (changeBy.length == 0) ? 0 : (changeBy.length < 3) ? changeBy[0] : changeBy[i];
            arr[i] = Math.min(255, Math.max(0, Integer.parseInt(strArr[i])+num));
        }
        return arr;
    }

    public int getAvg(String value){
        int total = 0;
        String[] arr = config.get(value).split(",");
        for(String s : arr){
            total += Integer.parseInt(s);
        }
        return total/3;
    }

    public Color makeC(int[] arr){
        return new Color(arr[0], arr[1], arr[2]);
    }
    
    public class CButton extends JButton {
        String str;
        @Override 
        protected void paintComponent(Graphics g){
            Rectangle bounds = getBounds();
            FontMetrics fm = g.getFontMetrics();
            int tW = fm.stringWidth(str);
            int tH = fm.getHeight();
            int width = bounds.width;
            int height = bounds.height;
            Graphics2D g2d = (Graphics2D)g;
            g2d.setStroke(new BasicStroke(3));
            //System.out.println(makeC(getSecondary()));
            g2d.setColor(makeC(getSecondary()));
            //g2d.drawRect(0, 0, width-3, height-4);
            g2d.drawRect(1, 1, width-2, height-2);
            g2d.setColor(makeC(getPrimary(-15)));
            g2d.fillRect(2, 2, width-3, height-3);
            g2d.setColor((getAvg("primaryColour") > 155) ? Color.BLACK : Color.WHITE);
            g2d.drawString(str, (width-tW)/2, (height-tH)/2 + fm.getAscent());
        }

        public CButton(String txt){
            super(txt);
            this.str = txt;
            setContentAreaFilled(false);
            setBorderPainted(false);
        }
        
    }
}
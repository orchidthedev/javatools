package src.tools;
import src.tools.Components.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
public class Main{
    private static JFrame frame;
    private static JPanel pane;
    private static File dir = null;
    private static JLabel dirLabel;
    protected static Components c;
    
    public static File[] getFiles(File dir){
        if(dir.exists() && dir.isDirectory()){
            return dir.listFiles();
        }
        else{
            return null;
        }
    }

    public static ArrayList<String> iterateFiles(File[] f, String search, boolean capsInsensetive, boolean name){
        ArrayList<String> res = new ArrayList<>();
        //System.out.println(capsInsensetive);
        //System.out.println(name);
        if(f != null){
                for(File file : f){
                    if(file.isDirectory()){
                        ArrayList<String> Res = iterateFiles(getFiles(file), search, capsInsensetive, name);
                        if(Res != null){
                            res.addAll(Res);
                        }
                    } else {
                        
                        if(name){
                            if(capsInsensetive){
                                if(file.getName().toLowerCase().contains(search.toLowerCase())){res.add(file.getAbsolutePath()); break;}
                            } else {
                                if(file.getName().contains(search)){res.add(file.getAbsolutePath()); break;}
                            }
                        } else {
                            try{
                                FileReader r = new FileReader(file.getAbsolutePath());
                                BufferedReader br = new BufferedReader(r);
                                String line;
                                int num = 1;
                                while((line = br.readLine()) != null){
                                    if(capsInsensetive){
                                        if(line.toLowerCase().contains(search.toLowerCase())){res.add(String.format("%s (%d):\n%s", file.getName(), num, line));}
                                    } else {
                                        if(line.contains(search)){res.add(String.format("%s (%d):\n%s", file.getName(), num, line));}
                                    }
                                    num++;
                                }
                                br.close();
                            } catch(IOException e){
                                e.printStackTrace();
                            }
                        }

                    }
                }
            }
        return (res.isEmpty()) ? null : res;
    }
    
    protected static HashMap<String,String> cfg = new HashMap<>() {{
        put("primaryColour", "45,45,45");
        put("secondaryColour", "255,25,25");
        put("tertiaryColour", "75,75,75");
    }};
    public static void main(String[] args){

        try{
            FileReader r = new FileReader("save.txt");
            BufferedReader br = new BufferedReader(r);
            String line;
            while((line = br.readLine()) != null){
                if(line.startsWith("dir")){
                    String[] s = line.split(":");
                    dir = new File(s[1]);
                }
            }
            br.close();
            r = new FileReader("config.txt");
            br = new BufferedReader(r);
            line = null;
            while((line = br.readLine()) != null){
                if(line.contains(":")){
                    String[] s = line.split(":");
                    cfg.put(s[0],s[1]);
                }
            }
            br.close();
        } catch (IOException e){
            e.printStackTrace();
        }
        
        c = new Components(cfg);
        pane = new JPanel();
        pane.setLayout(null);
        frame = new JFrame();
        frame.setLayout(null);
        frame.setSize(500,575);
        pane.setBackground(c.makeC(c.getTertiary(5)));
        
        JTextArea ta = new JTextArea();
        ta.setBounds(25,25,250,50);
        ta.setBackground(c.makeC(c.getTertiary(-10)));
        System.out.println(c.makeC(c.getTertiary(-10)));
        ta.setForeground((c.getAvg("tertiaryColour") > 155) ? Color.BLACK : Color.WHITE);
        pane.add(ta);

        JCheckBox name = new JCheckBox("Search by name");
        name.setBounds(300,30,150,25);
        pane.add(name);
        name.setBackground(c.makeC(c.getTertiary(5)));
        name.setForeground((c.getAvg("tertiaryColour") > 155) ? Color.BLACK : Color.WHITE);

        JCheckBox caps = new JCheckBox("Caps insensetive");
        caps.setBounds(300,65,150,25);
        pane.add(caps);
        caps.setBackground(c.makeC(c.getTertiary(5)));
        caps.setForeground((c.getAvg("tertiaryColour") > 155) ? Color.BLACK : Color.WHITE);

        JLabel label = new JLabel();
        
        label.setBackground(c.makeC(c.getTertiary(-10)));
        Color bg = c.makeC(c.getTertiary(-10));
        //label.setText(String.format("<html><body style = \"background-color: rgb(%d,%d,%d);\"></body></html>", bg.getRed(), bg.getGreen(), bg.getBlue()));
        JScrollPane sp = new JScrollPane(label);
        sp.getViewport().setBackground(c.makeC(c.getTertiary(-10)));
        sp.setBackground(c.makeC(c.getTertiary(-10)));
        label.setForeground((c.getAvg("tertiaryColour")-10 > 155) ? Color.BLACK : Color.WHITE);
        
        sp.setPreferredSize(new Dimension(350, 350));
        sp.setBounds(25, 100, 350, 350);
        pane.add(sp);

        dirLabel = new JLabel(String.format("<html><body style='width: %1spx'>%1s", 375, "Directory: " + ((dir == null) ? "not set" : dir.getAbsolutePath())));
        dirLabel.setBackground(c.makeC(c.getTertiary(5)));
        dirLabel.setForeground((c.getAvg("tertiaryColour")+5 > 155) ? Color.BLACK : Color.WHITE);
        dirLabel.setBounds(25, 460, 450, 100);
        pane.add(dirLabel);
        CButton selectFile = c.new CButton("Select Directory");
        selectFile.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                JFileChooser fc = new JFileChooser();
                fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int r = fc.showSaveDialog(null);
                if(r == JFileChooser.APPROVE_OPTION){
                    dir = fc.getSelectedFile();
                    System.out.print(dir.getAbsolutePath());
                    dirLabel.setText(String.format("<html><body style='width: %1spx'>%1s", 375, "Directory: " + dir.getAbsolutePath()));
                }
            }
        });
        selectFile.setBounds(380, 120, 100, 40);
        pane.add(selectFile);
        
        CButton btn = c.new CButton("Search");
        btn.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if(dir != null && getFiles(dir) != null){
                    ArrayList<String> res = iterateFiles(getFiles(dir), ta.getText(), caps.isSelected(), name.isSelected());
                    if(res != null){
                        int num = 1;
                        String str = "<html>";//String.format("<html><body style = \"background-color: rgb(%d,%d,%d);\">", bg.getRed(), bg.getGreen(), bg.getBlue());
                        for(String line : res){
                            str += num + ": " + line+"<br>";
                            num++;
                        }
                        str += "</html>";
                        label.setText(str);
                    } else {
                        label.setText("No results found.");
                    }
                }
            }
        });
        btn.setBounds(380, 170, 100, 40);
        pane.add(btn);

        CButton theme = c.new CButton("Theme");
        theme.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                ThemeMenu tm = new ThemeMenu();
            }
        });
        theme.setBounds(380, 220, 100, 40);
        pane.add(theme);
        
        frame.setContentPane(pane);
        frame.setVisible(true);
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try{
                    if(dir != null){
                        FileWriter w = new FileWriter("save.txt");
                        BufferedWriter bw = new BufferedWriter(w);
                        bw.write("dir:" + dir.getAbsolutePath());
                        bw.close();
                        w = new FileWriter("config.txt");
                        bw = new BufferedWriter(w);
                        String[] keys = cfg.keySet().toArray(new String[0]);
                        String Ln = "";
                        for(String key : keys){
                            Ln += key+":"+cfg.get(key) + "\n";
                        }
                        bw.write(Ln);
                        bw.close();
                    }
                } catch(IOException err){
                    err.printStackTrace();
                }
            }
        });
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    protected static void resetFrame(){
        try{
            if(dir != null){
                FileWriter w = new FileWriter("save.txt");
                BufferedWriter bw = new BufferedWriter(w);
                bw.write("dir:" + dir.getAbsolutePath());
                bw.close();
                w = new FileWriter("config.txt");
                bw = new BufferedWriter(w);
                String[] keys = cfg.keySet().toArray(new String[0]);
                String Ln = "";
                for(String key : keys){
                    Ln += key+":"+cfg.get(key) + "\n";
                }
                bw.write(Ln);
                bw.close();
            }
        } catch(IOException err){
            err.printStackTrace();
        }
        frame.dispose();
        main(new String[0]);
    }
}
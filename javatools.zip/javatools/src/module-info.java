module tools {
    requires java.desktop;
}
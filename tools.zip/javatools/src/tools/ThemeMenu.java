package src.tools;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import src.tools.Components.*;
public class ThemeMenu extends JFrame {
	private Runnable repaintCallback = null;
	public ThemeMenu() {
		JPanel pane = new JPanel();
		setLayout(null);
		pane.setLayout(null);
		setSize(600,400);
		pane.setBackground(Main.c.makeC(Main.c.getTertiary(10)));
		JColorChooser cc = new JColorChooser();
		cc.setBounds(0,0,600,300);
		cc.setBackground(Main.c.makeC(Main.c.getTertiary(10)));
		cc.setForeground(Main.c.makeC(Main.c.getTertiary(5)));
		CButton pc = Main.c.new CButton("Set Primary");
		CButton sc = Main.c.new CButton("Set Secondary");
		CButton tc = Main.c.new CButton("Set Tertiary");
		pc.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Color c = cc.getColor();
				Main.cfg.put("primaryColour", String.format("%d,%d,%d", c.getRed(), c.getGreen(), c.getBlue()));
				callRepaint();
			}
			
		});
		sc.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Color c = cc.getColor();
				Main.cfg.put("secondaryColour", String.format("%d,%d,%d", c.getRed(), c.getGreen(), c.getBlue()));
				callRepaint();
			}
			
		});
		tc.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Color c = cc.getColor();
				Main.cfg.put("tertiaryColour", String.format("%d,%d,%d", c.getRed(), c.getGreen(), c.getBlue()));
				callRepaint();
			}
			
		});
		pane.add(cc);
		pc.setBounds(50,300,100,50);
		sc.setBounds(300,300,100,50);
		tc.setBounds(475,300,100,50);
		pane.add(pc);
		pane.add(sc);
		pane.add(tc);
		
		setContentPane(pane);
		setVisible(true);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                Main.resetFrame();
            }
        });
	}
	
	public void setRepaintCallback(Runnable r){
		repaintCallback = r;
	}
	
	private void callRepaint() {
		if(repaintCallback != null) {
			repaintCallback.run();
		}
	}
}